﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DWilliams_GOL
{
    public partial class Form1 : Form
    {
        // The universe array
        bool[,] universe = new bool[25, 25];
        bool[,] scratchPad;

        // Drawing colors
        Color gridColor = Color.Black;
        Color cellColor = Color.Gray;

        // The Timer class
        Timer timer = new Timer();

        // Generation count
        int generations = 0;

        public Form1()
        {
            InitializeComponent();
        }

        // Calculate the next generation of cells
        private void NextGeneration()
        {
            //Sets dead/alive state for cells in next gen
            CellState();
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    universe[x, y] = scratchPad[x, y];
                }
            }
            graphicsPanel1.Invalidate();

            // Increment generation count
            generations++;

            // Update status strip generations
            toolStripStatusLabelGenerations.Text = "Generations = " + generations.ToString();
        }

        // The event called by the timer every Interval milliseconds.
        private void Timer_Tick(object sender, EventArgs e)
        {
            NextGeneration();
        }

        private void graphicsPanel1_Paint(object sender, PaintEventArgs e)
        {
            // Calculate the width and height of each cell in pixels
            // CELL WIDTH = WINDOW WIDTH / NUMBER OF CELLS IN X
            int cellWidth = graphicsPanel1.ClientSize.Width / universe.GetLength(0);
            // CELL HEIGHT = WINDOW HEIGHT / NUMBER OF CELLS IN Y
            int cellHeight = graphicsPanel1.ClientSize.Height / universe.GetLength(1);

            // A Pen for drawing the grid lines (color, width)
            Pen gridPen = new Pen(gridColor, 1);

            // A Brush for filling living cells interiors (color)
            Brush cellBrush = new SolidBrush(cellColor);

            // Iterate through the universe in the y, top to bottom
            for (int y = 0; y < universe.GetLength(1); y++)
            {
                // Iterate through the universe in the x, left to right
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    // A rectangle to represent each cell in pixels
                    Rectangle cellRect = Rectangle.Empty;
                    cellRect.X = x * cellWidth;
                    cellRect.Y = y * cellHeight;
                    cellRect.Width = cellWidth;
                    cellRect.Height = cellHeight;

                    

                    // Fill the cell with a brush if alive
                    if (universe[x, y] == true)
                    {
                        e.Graphics.FillRectangle(cellBrush, cellRect);
                    }

                    // Outline the cell with a pen
                    e.Graphics.DrawRectangle(gridPen, cellRect.X, cellRect.Y, cellRect.Width, cellRect.Height);
                }
            }

            // Cleaning up pens and brushes
            gridPen.Dispose();
            cellBrush.Dispose();
        }

        private void graphicsPanel1_MouseClick(object sender, MouseEventArgs e)
        {
            // If the left mouse button was clicked
            if (e.Button == MouseButtons.Left)
            {
                // Calculate the width and height of each cell in pixels
                int cellWidth = graphicsPanel1.ClientSize.Width / universe.GetLength(0);
                int cellHeight = graphicsPanel1.ClientSize.Height / universe.GetLength(1);

                // Calculate the cell that was clicked in
                // CELL X = MOUSE X / CELL WIDTH
                int x = e.X / cellWidth;
                // CELL Y = MOUSE Y / CELL HEIGHT
                int y = e.Y / cellHeight;

                // Toggle the cell's state
                universe[x, y] = !universe[x, y];

                // Tell Windows you need to repaint
                graphicsPanel1.Invalidate();
            }
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            if (generations == 0)
            {
                timer.Interval = 100;
                timer.Tick += Timer_Tick;
                timer.Enabled = true;
            }
            else
            {
                timer.Enabled = true;
            }
        }

        private void PauseButton_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
        }

        private void NextButton_Click(object sender, EventArgs e)
        {
            NextGeneration();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            generations = 1;
            timer.Dispose();
            
            for(int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    universe[x, y] = false;
                    scratchPad[x, y] = false;
                }
            }

            graphicsPanel1.Invalidate();
        }

        //Makes array according to the grid size and set each cell with how many neighbors it has to calculate life or death in next gen
        //private void SetNeighborNum()
        //{
        //    if (neighborCount == null)
        //    {
        //        neighborCount = new int[universe.GetLength(0), universe.GetLength(1)];
        //    }

        //    for (int y = 0; y < universe.GetLength(1); y++)
        //    {
        //        for (int x = 0; x < universe.GetLength(0); x++)
        //        {
        //            neighborCount[x, y] = 0;
        //            neighborCount[x, y] = CountNeighborsTorodial(x, y);
        //        }
        //    }
        //}

        //Counts amunt of neighbors a cell has
        private int CountNeighborsTorodial(int x, int y)
        {
            int count = 0;
            int xLen = universe.GetLength(0);
            int yLen = universe.GetLength(1);

            for (int yOffSet = -1; yOffSet <= 1; yOffSet++)
            {
                for (int xOffSet = -1; xOffSet <= 1; xOffSet++)
                {
                    int xCheck = x + xOffSet;
                    int yCheck = y + yOffSet;

                    if (xOffSet == 0 && yOffSet == 0) continue;

                    if (xCheck < 0)
                    {
                        xCheck = xLen - 1;
                    }

                    if (yCheck < 0)
                    {
                        yCheck = yLen - 1;
                    }

                    if (xCheck >= xLen)
                    {
                        xCheck = 0;
                    }

                    if (yCheck >= yLen)
                    {
                        yCheck = 0;
                    }

                    if (universe[xCheck, yCheck] == true) count++;
                }
            }

            return count;
        }

        //Determines whether or not a cell will be alive in the next generation
        private void CellState()
        {
            scratchPad = new bool[universe.GetLength(0), universe.GetLength(1)];

            for (int y = 0; y < universe.GetLength(1); y++)
            {
                for (int x = 0; x < universe.GetLength(0); x++)
                {
                    if ((CountNeighborsTorodial(x, y) < 2) && universe[x, y])
                    {
                        scratchPad[x, y] = false;
                    }
                    else if ((CountNeighborsTorodial(x, y) > 3) && universe[x, y])
                    {
                        scratchPad[x, y] = false;
                    }
                    else if ((CountNeighborsTorodial(x, y) == 2 || CountNeighborsTorodial(x, y) == 3) && universe[x, y])
                    {
                        scratchPad[x, y] = true;
                    }
                    else if ((CountNeighborsTorodial(x, y) == 3) && universe[x, y] == false)
                    {
                        scratchPad[x, y] = true;
                    }
                }
            }
        }
    }
}